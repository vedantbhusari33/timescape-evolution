import { useState, useCallback } from 'react'
import LoadingScreen from './components/LoadingScreen'
import CustomCursor from './components/CustomCursor'
import ProgressBar from './components/ProgressBar'
import Hero from './components/Hero'
import EarlyInternet from './components/EarlyInternet'
import SocialMedia from './components/SocialMedia'
import MobileEra from './components/MobileEra'
import FutureWeb from './components/FutureWeb'
import SectionTransition from './components/SectionTransition'

export default function App() {
  const [loaded, setLoaded] = useState(false)

  const handleLoadComplete = useCallback(() => {
    setLoaded(true)
  }, [])

  return (
    <>
      {/* Custom cursor — desktop only */}
      <div className="hidden md:block">
        <CustomCursor />
      </div>

      {/* Loading screen */}
      <LoadingScreen onComplete={handleLoadComplete} />

      {/* Main content */}
      <main
        style={{
          opacity: loaded ? 1 : 0,
          transition: 'opacity 0.5s ease',
          paddingBottom: '3rem', // space for mobile nav
        }}
      >
        {/* Scroll progress + nav */}
        <ProgressBar />

        {/* Sections */}
        <Hero />

        <SectionTransition fromColor="#000000" toColor="#050505" />

        <EarlyInternet />

        <SectionTransition fromColor="#050505" toColor="#0a0010" />

        <SocialMedia />

        <SectionTransition fromColor="#0a0010" toColor="#08001a" />

        <MobileEra />

        <SectionTransition fromColor="#08001a" toColor="#000008" />

        <FutureWeb />

        {/* Footer */}
        <footer
          className="relative py-16 text-center border-t border-white/5"
          style={{ background: '#000008' }}
        >
          <div className="font-future text-xs text-[#00f5ff]/30 tracking-[0.4em] mb-2">
            TIMESCAPE
          </div>
          <div className="font-mono text-[10px] text-white/15 tracking-widest">
            EVOLUTION OF THE INTERNET — 1969 TO ∞
          </div>
          <div className="font-mono text-[10px] text-white/10 mt-4">
            Built with React · Framer Motion · Tailwind CSS
          </div>
        </footer>
      </main>
    </>
  )
}
