import { useRef, useState } from 'react'
import { motion, useScroll, useTransform, useInView } from 'framer-motion'
import { mobileStats } from '../data/timeline'

const phoneApps = [
  { name: 'Maps', icon: '🗺️', color: '#34c759' },
  { name: 'Music', icon: '🎵', color: '#fc3c44' },
  { name: 'Camera', icon: '📷', color: '#bf5af2' },
  { name: 'Pay', icon: '💳', color: '#30d158' },
  { name: 'Health', icon: '❤️', color: '#ff375f' },
  { name: 'Uber', icon: '🚗', color: '#000' },
  { name: 'Spotify', icon: '🎧', color: '#1db954' },
  { name: 'TikTok', icon: '🎬', color: '#010101' },
  { name: 'Notion', icon: '📝', color: '#fff' },
  { name: 'GPT', icon: '🤖', color: '#10a37f' },
  { name: 'Maps', icon: '🌍', color: '#007aff' },
  { name: 'Shop', icon: '🛍️', color: '#ff9f0a' },
]

function PhoneMockup() {
  const [activeApp, setActiveApp] = useState(null)

  return (
    <div className="relative flex justify-center">
      <motion.div
        className="relative w-[260px] rounded-[40px] overflow-hidden phone-shadow"
        style={{ background: '#1a1a1a', border: '8px solid #2a2a2a' }}
        initial={{ y: 60, opacity: 0 }}
        whileInView={{ y: 0, opacity: 1 }}
        viewport={{ once: true }}
        transition={{ duration: 1, ease: [0.16, 1, 0.3, 1] }}
        animate={{ y: [0, -10, 0] }}
      >
        {/* Notch */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-24 h-6 bg-black rounded-b-2xl z-10" />

        {/* Screen */}
        <div className="bg-gradient-to-b from-[#1c1c2e] to-[#0a0a1a] min-h-[500px] px-4 pt-10 pb-6">
          {/* Status bar */}
          <div className="flex justify-between items-center mb-4 px-1">
            <span className="font-mono text-[10px] text-white/60">9:41</span>
            <div className="flex gap-1 items-center">
              <div className="flex gap-[2px]">
                {[1, 2, 3, 4].map(i => (
                  <div key={i} className="w-[3px] rounded-sm bg-white/70" style={{ height: i * 3 }} />
                ))}
              </div>
              <div className="w-5 h-2.5 rounded-sm border border-white/70 ml-1 relative">
                <div className="absolute inset-[2px] right-[4px] bg-white/70 rounded-sm" />
                <div className="absolute -right-[3px] top-[3px] w-[3px] h-[4px] bg-white/40 rounded-r-sm" />
              </div>
            </div>
          </div>

          {/* App grid */}
          <div className="grid grid-cols-3 gap-3 px-2">
            {phoneApps.map((app, i) => (
              <motion.button
                key={`${app.name}-${i}`}
                className="flex flex-col items-center gap-1"
                whileTap={{ scale: 0.9 }}
                onClick={() => setActiveApp(activeApp === i ? null : i)}
                data-cursor="hover"
              >
                <motion.div
                  className="w-14 h-14 rounded-2xl flex items-center justify-center text-2xl"
                  style={{
                    background: activeApp === i ? `${app.color}44` : 'rgba(255,255,255,0.08)',
                    border: activeApp === i ? `1px solid ${app.color}` : '1px solid rgba(255,255,255,0.1)',
                  }}
                  animate={{
                    boxShadow: activeApp === i ? `0 0 15px ${app.color}66` : 'none',
                  }}
                >
                  {app.icon}
                </motion.div>
                <span className="font-body text-[9px] text-white/50">{app.name}</span>
              </motion.button>
            ))}
          </div>

          {/* Bottom dock */}
          <div className="mt-6 mx-2 rounded-2xl bg-white/10 backdrop-blur-lg p-3 flex justify-around border border-white/10">
            {['📞', '📧', '🌐', '⚙️'].map((icon, i) => (
              <motion.button
                key={i}
                className="w-12 h-12 rounded-xl bg-white/10 flex items-center justify-center text-xl"
                whileTap={{ scale: 0.85 }}
                whileHover={{ scale: 1.1, background: 'rgba(255,255,255,0.2)' }}
              >
                {icon}
              </motion.button>
            ))}
          </div>

          {/* Home indicator */}
          <div className="flex justify-center mt-4">
            <div className="w-24 h-1 rounded-full bg-white/30" />
          </div>
        </div>
      </motion.div>

      {/* Floating notification badges */}
      {[
        { label: '23 Messages', color: '#ff375f', top: '15%', right: '-20px' },
        { label: '5G Active', color: '#30d158', top: '40%', left: '-20px' },
        { label: 'AI Reply', color: '#bf5af2', top: '65%', right: '-20px' },
      ].map((badge, i) => (
        <motion.div
          key={badge.label}
          className="absolute font-mono text-[10px] px-3 py-1.5 rounded-full border text-white whitespace-nowrap"
          style={{
            top: badge.top,
            right: badge.right,
            left: badge.left,
            borderColor: `${badge.color}66`,
            background: `${badge.color}15`,
            color: badge.color,
          }}
          initial={{ opacity: 0, x: badge.right ? 20 : -20 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.5 + i * 0.2, duration: 0.6 }}
          animate={{ y: [0, -5, 0] }}
        >
          {badge.label}
        </motion.div>
      ))}
    </div>
  )
}

export default function MobileEra() {
  const ref = useRef(null)
  const sectionRef = useRef(null)
  const inView = useInView(sectionRef, { once: true, margin: '-20%' })
  const { scrollYProgress } = useScroll({ target: ref, offset: ['start end', 'end start'] })
  const bgY = useTransform(scrollYProgress, [0, 1], ['-5%', '5%'])

  return (
    <section
      id="mobile-era"
      ref={ref}
      className="relative min-h-screen overflow-hidden"
      style={{ background: '#08001a' }}
    >
      <motion.div className="absolute inset-0" style={{ y: bgY }}>
        <div className="absolute inset-0"
          style={{
            background: 'radial-gradient(ellipse at 30% 40%, #bf5af222 0%, transparent 55%), radial-gradient(ellipse at 70% 60%, #007aff22 0%, transparent 55%)',
          }}
        />
        {/* Subtle grid */}
        <div className="absolute inset-0 grid-bg opacity-10" />
      </motion.div>

      <div className="noise-overlay" />

      <div ref={sectionRef} className="relative z-10 max-w-6xl mx-auto px-6 py-24 lg:py-32">

        {/* Header */}
        <motion.div
          className="mb-16"
          initial={{ opacity: 0, y: 40 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
        >
          <div className="font-mono text-xs text-[#bf5af2]/60 tracking-[0.5em] mb-3">
            CHAPTER_03 / THE_POCKET_COMPUTER
          </div>
          <h2
            className="font-display text-[clamp(3rem,10vw,8rem)] leading-none"
            style={{
              background: 'linear-gradient(135deg, #bf5af2, #007aff)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
              backgroundClip: 'text',
            }}
          >
            MOBILE<br />ERA
          </h2>
          <div className="font-mono text-white/30 mt-2 text-sm">2010s — Everything in Your Pocket</div>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Left: Phone */}
          <PhoneMockup />

          {/* Right: Content */}
          <div className="space-y-8">
            <motion.p
              className="font-body text-lg text-white/60 leading-relaxed"
              initial={{ opacity: 0, x: 40 }}
              animate={inView ? { opacity: 1, x: 0 } : {}}
              transition={{ delay: 0.3, duration: 0.7 }}
            >
              The smartphone didn't just change <span className="text-white">how</span> we use the internet — 
              it changed <span className="text-white">who we are</span>. Billions became always-connected, 
              always-visible nodes in a global network.
            </motion.p>

            {/* Stats */}
            <div className="grid grid-cols-2 gap-4">
              {mobileStats.map((stat, i) => (
                <motion.div
                  key={stat.label}
                  className="rounded-2xl p-5 border border-[#bf5af2]/20 bg-[#bf5af2]/5"
                  initial={{ opacity: 0, y: 20 }}
                  animate={inView ? { opacity: 1, y: 0 } : {}}
                  transition={{ delay: 0.4 + i * 0.1, duration: 0.6 }}
                  whileHover={{
                    borderColor: '#bf5af2',
                    boxShadow: '0 0 25px rgba(191,90,242,0.2)',
                    scale: 1.03,
                  }}
                  data-cursor="hover"
                >
                  <div className="text-2xl mb-2">{stat.icon}</div>
                  <div className="font-display text-3xl text-[#bf5af2]">{stat.value}</div>
                  <div className="font-body text-xs text-white/50 mt-1">{stat.label}</div>
                  <div className="font-mono text-[10px] text-[#bf5af2]/40">{stat.unit}</div>
                </motion.div>
              ))}
            </div>

            {/* Timeline milestones */}
            <motion.div
              className="space-y-3"
              initial={{ opacity: 0 }}
              animate={inView ? { opacity: 1 } : {}}
              transition={{ delay: 0.8 }}
            >
              {[
                { year: '2007', text: 'iPhone launched — the first modern smartphone' },
                { year: '2008', text: 'App Store opens — a new economy is born' },
                { year: '2012', text: '1 billion smartphones in use worldwide' },
                { year: '2016', text: 'Mobile surpasses desktop internet traffic' },
                { year: '2023', text: '6.9 billion smartphone users globally' },
              ].map((item, i) => (
                <motion.div
                  key={item.year}
                  className="flex items-start gap-4"
                  initial={{ opacity: 0, x: 20 }}
                  animate={inView ? { opacity: 1, x: 0 } : {}}
                  transition={{ delay: 0.9 + i * 0.08 }}
                >
                  <span className="font-mono text-xs text-[#007aff] flex-shrink-0 mt-0.5 w-10">{item.year}</span>
                  <div className="w-1.5 h-1.5 rounded-full bg-[#bf5af2]/60 flex-shrink-0 mt-1.5" />
                  <span className="font-body text-sm text-white/50">{item.text}</span>
                </motion.div>
              ))}
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  )
}
