import { motion } from 'framer-motion'
import { useScrollProgress } from '../hooks/useScrollProgress'
import { timelineData } from '../data/timeline'

export default function ProgressBar() {
  const { progress, activeSection } = useScrollProgress()

  const scrollTo = (id) => {
    const el = document.getElementById(id)
    if (el) el.scrollIntoView({ behavior: 'smooth' })
  }

  return (
    <>
      {/* Top progress bar */}
      <div className="fixed top-0 left-0 right-0 z-50 h-[3px] bg-white/5">
        <motion.div
          className="h-full progress-bar"
          style={{ width: `${progress * 100}%` }}
        />
      </div>

      {/* Side timeline nav — desktop */}
      <nav className="fixed right-6 top-1/2 -translate-y-1/2 z-50 hidden lg:flex flex-col items-end gap-4">
        {timelineData.map((item) => {
          const isActive = activeSection === item.id
          return (
            <button
              key={item.id}
              onClick={() => scrollTo(item.id)}
              className="timeline-nav-btn group flex items-center gap-3"
              data-cursor="hover"
            >
              {/* Label */}
              <motion.div
                className="font-mono text-xs text-right overflow-hidden"
                initial={{ width: 0, opacity: 0 }}
                animate={{
                  width: isActive ? 'auto' : 0,
                  opacity: isActive ? 1 : 0,
                }}
                transition={{ duration: 0.3 }}
              >
                <span style={{ color: item.color }} className="whitespace-nowrap pr-1">
                  {item.year}
                </span>
              </motion.div>

              {/* Dot */}
              <motion.div
                className="w-3 h-3 rounded-full border-2 transition-all duration-300 flex-shrink-0"
                style={{
                  borderColor: isActive ? item.color : 'rgba(255,255,255,0.3)',
                  background: isActive ? item.color : 'transparent',
                  boxShadow: isActive ? `0 0 10px ${item.color}, 0 0 20px ${item.color}` : 'none',
                }}
                animate={isActive ? { scale: [1, 1.3, 1] } : { scale: 1 }}
                transition={{ duration: 1, repeat: isActive ? Infinity : 0 }}
              />
            </button>
          )
        })}
      </nav>

      {/* Bottom mobile nav */}
      <nav className="fixed bottom-0 left-0 right-0 z-50 lg:hidden bg-black/80 backdrop-blur-lg border-t border-white/10 px-2 py-2 flex justify-around">
        {timelineData.map((item) => {
          const isActive = activeSection === item.id
          return (
            <button
              key={item.id}
              onClick={() => scrollTo(item.id)}
              className="flex flex-col items-center gap-1 px-2 py-1"
            >
              <div
                className="w-2 h-2 rounded-full transition-all duration-300"
                style={{
                  background: isActive ? item.color : 'rgba(255,255,255,0.3)',
                  boxShadow: isActive ? `0 0 8px ${item.color}` : 'none',
                }}
              />
              <span
                className="font-mono text-[9px] transition-colors duration-300"
                style={{ color: isActive ? item.color : 'rgba(255,255,255,0.4)' }}
              >
                {item.label}
              </span>
            </button>
          )
        })}
      </nav>
    </>
  )
}
