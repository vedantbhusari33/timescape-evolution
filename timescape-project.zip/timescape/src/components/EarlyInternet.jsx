import { useRef, useState } from 'react'
import { motion, useScroll, useTransform, useInView } from 'framer-motion'
import { earlyInternetEvents } from '../data/timeline'

function TerminalLine({ text, delay = 0 }) {
  const ref = useRef(null)
  const inView = useInView(ref, { once: true, margin: '-10%' })
  return (
    <motion.div
      ref={ref}
      className="font-mono text-sm text-[#00ff41]"
      initial={{ opacity: 0, x: -20 }}
      animate={inView ? { opacity: 1, x: 0 } : {}}
      transition={{ delay, duration: 0.5 }}
    >
      {text}
    </motion.div>
  )
}

function EventCard({ event, index }) {
  const ref = useRef(null)
  const inView = useInView(ref, { once: true, margin: '-5%' })
  const [hovered, setHovered] = useState(false)

  return (
    <motion.div
      ref={ref}
      className="relative flex gap-6 group"
      initial={{ opacity: 0, x: index % 2 === 0 ? -60 : 60 }}
      animate={inView ? { opacity: 1, x: 0 } : {}}
      transition={{ delay: index * 0.1, duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
    >
      {/* Timeline line */}
      <div className="flex flex-col items-center flex-shrink-0">
        <motion.div
          className="w-4 h-4 rounded-full border-2 border-[#00ff41] bg-black flex-shrink-0 relative z-10"
          animate={{ boxShadow: hovered ? '0 0 15px #00ff41, 0 0 30px #00ff41' : '0 0 5px #00ff41' }}
          onHoverStart={() => setHovered(true)}
          onHoverEnd={() => setHovered(false)}
        />
        {index < earlyInternetEvents.length - 1 && (
          <div className="w-[1px] flex-1 mt-1 bg-gradient-to-b from-[#00ff41]/40 to-transparent min-h-[40px]" />
        )}
      </div>

      {/* Content */}
      <motion.div
        className="pb-8 cursor-default"
        onHoverStart={() => setHovered(true)}
        onHoverEnd={() => setHovered(false)}
        whileHover={{ x: 4 }}
        transition={{ duration: 0.2 }}
      >
        <span className="font-mono text-xs text-[#ffb000] tracking-widest">{event.year}</span>
        <h3 className="font-mono text-base text-[#00ff41] mt-1 group-hover:text-white transition-colors duration-200">
          {event.event}
        </h3>
        <p className="font-body text-sm text-[#00ff41]/50 mt-1 group-hover:text-[#00ff41]/80 transition-colors duration-200">
          {event.desc}
        </p>
      </motion.div>
    </motion.div>
  )
}

export default function EarlyInternet() {
  const ref = useRef(null)
  const { scrollYProgress } = useScroll({ target: ref, offset: ['start end', 'end start'] })
  const bgY = useTransform(scrollYProgress, [0, 1], ['-10%', '10%'])

  const sectionRef = useRef(null)
  const inView = useInView(sectionRef, { once: true, margin: '-20%' })

  return (
    <section
      id="early-internet"
      ref={ref}
      className="relative min-h-screen overflow-hidden"
      style={{ background: '#050505' }}
    >
      {/* CRT background parallax */}
      <motion.div
        className="absolute inset-0"
        style={{ y: bgY }}
      >
        <div
          className="absolute inset-0"
          style={{
            background: 'radial-gradient(ellipse at 50% 50%, #001a00 0%, #050505 70%)',
          }}
        />
        {/* CRT grid */}
        <div
          className="absolute inset-0 opacity-10"
          style={{
            backgroundImage: 'repeating-linear-gradient(0deg, transparent, transparent 2px, rgba(0,255,65,0.03) 2px, rgba(0,255,65,0.03) 4px)',
          }}
        />
      </motion.div>

      {/* CRT scan line */}
      <div className="crt-scanline" />

      {/* Noise */}
      <div className="noise-overlay" />

      <div ref={sectionRef} className="relative z-10 max-w-6xl mx-auto px-6 py-24 lg:py-32">

        {/* Section header */}
        <motion.div
          className="mb-16"
          initial={{ opacity: 0, y: 40 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
        >
          <div className="font-mono text-xs text-[#00ff41]/50 tracking-[0.5em] mb-3">
            CHAPTER_01 / ARPANET_TO_WWW
          </div>
          <h2 className="font-display text-[clamp(3rem,10vw,8rem)] leading-none text-[#00ff41]"
            style={{ textShadow: '0 0 40px rgba(0,255,65,0.4)' }}>
            EARLY<br />INTERNET
          </h2>
          <div className="font-mono text-[#00ff41]/40 mt-2 text-sm">1960s — 1990s</div>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-12 lg:gap-20">

          {/* Left: Terminal */}
          <motion.div
            initial={{ opacity: 0, y: 60 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            <div className="bg-black border border-[#00ff41]/30 rounded overflow-hidden"
              style={{ boxShadow: '0 0 30px rgba(0,255,65,0.1)' }}>
              {/* Terminal header */}
              <div className="flex items-center gap-2 px-4 py-3 border-b border-[#00ff41]/20 bg-[#00ff41]/5">
                <div className="w-3 h-3 rounded-full bg-[#ff5f57]" />
                <div className="w-3 h-3 rounded-full bg-[#febc2e]" />
                <div className="w-3 h-3 rounded-full bg-[#28c840]" />
                <span className="font-mono text-xs text-[#00ff41]/50 ml-2">ARPANET_TERMINAL v1.0</span>
              </div>
              {/* Terminal body */}
              <div className="p-5 space-y-2 min-h-[280px]">
                <TerminalLine text="$ connect arpanet" delay={0.3} />
                <TerminalLine text="> Connecting to node..." delay={0.6} />
                <TerminalLine text="> Status: ONLINE" delay={0.9} />
                <TerminalLine text="$ ping stanford.edu" delay={1.2} />
                <TerminalLine text="> 64 bytes from 36.0: time=2847ms" delay={1.5} />
                <TerminalLine text="$ whoami" delay={1.8} />
                <TerminalLine text="> user@ucla.arpanet" delay={2.1} />
                <TerminalLine text="$ history --internet" delay={2.4} />
                <TerminalLine text="> Loading 60 years of data..." delay={2.7} />
                <div className="font-mono text-sm text-[#00ff41] terminal-cursor" style={{ animationDelay: '3s' }} />
              </div>
            </div>

            {/* Stats row */}
            <div className="grid grid-cols-3 gap-3 mt-4">
              {[
                { label: 'First Nodes', value: '4' },
                { label: 'Year Founded', value: '\'69' },
                { label: 'Protocol', value: 'TCP/IP' },
              ].map((stat) => (
                <motion.div
                  key={stat.label}
                  className="bg-black border border-[#00ff41]/20 rounded p-3 text-center"
                  whileHover={{ borderColor: '#00ff41', boxShadow: '0 0 15px rgba(0,255,65,0.2)' }}
                  data-cursor="hover"
                >
                  <div className="font-mono text-xl text-[#00ff41]">{stat.value}</div>
                  <div className="font-mono text-[10px] text-[#00ff41]/40 mt-1">{stat.label}</div>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Right: Timeline events */}
          <motion.div
            initial={{ opacity: 0, y: 60 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.4 }}
          >
            <div className="font-mono text-xs text-[#00ff41]/40 tracking-widest mb-6">
              KEY_MILESTONES ::
            </div>
            {earlyInternetEvents.map((event, i) => (
              <EventCard key={event.year} event={event} index={i} />
            ))}
          </motion.div>
        </div>

        {/* Bottom quote */}
        <motion.blockquote
          className="mt-16 border-l-2 border-[#00ff41]/40 pl-6 max-w-2xl"
          initial={{ opacity: 0 }}
          animate={inView ? { opacity: 1 } : {}}
          transition={{ delay: 0.8, duration: 0.8 }}
        >
          <p className="font-mono text-sm text-[#00ff41]/60 italic leading-relaxed">
            "The original message sent over ARPANET was 'LO' — the system crashed before they could send 'LOGIN'. The internet started with a bang... then a crash."
          </p>
          <cite className="font-mono text-xs text-[#00ff41]/30 mt-2 block">— Internet History, 1969</cite>
        </motion.blockquote>
      </div>
    </section>
  )
}
