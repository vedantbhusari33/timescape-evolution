import { useRef, useEffect } from 'react'
import { motion, useScroll, useTransform } from 'framer-motion'

const STAR_COUNT = 120

function Stars() {
  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none">
      {Array.from({ length: STAR_COUNT }).map((_, i) => {
        const size = Math.random() * 2.5 + 0.5
        const x = Math.random() * 100
        const y = Math.random() * 100
        const dur = 2 + Math.random() * 4
        const delay = Math.random() * 4
        return (
          <div
            key={i}
            className="star"
            style={{
              width: size,
              height: size,
              left: `${x}%`,
              top: `${y}%`,
              '--duration': `${dur}s`,
              '--delay': `${delay}s`,
            }}
          />
        )
      })}
    </div>
  )
}

export default function Hero() {
  const ref = useRef(null)
  const { scrollYProgress } = useScroll({ target: ref, offset: ['start start', 'end start'] })

  // Parallax transforms
  const titleY = useTransform(scrollYProgress, [0, 1], [0, 150])
  const subtitleY = useTransform(scrollYProgress, [0, 1], [0, 80])
  const starsY = useTransform(scrollYProgress, [0, 1], [0, 200])
  const opacity = useTransform(scrollYProgress, [0, 0.7], [1, 0])
  const scale = useTransform(scrollYProgress, [0, 1], [1, 1.08])

  const containerVariants = {
    hidden: {},
    visible: { transition: { staggerChildren: 0.15, delayChildren: 0.2 } },
  }

  const itemVariants = {
    hidden: { opacity: 0, y: 40 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.9, ease: [0.16, 1, 0.3, 1] } },
  }

  return (
    <section
      id="hero"
      ref={ref}
      className="relative min-h-screen flex flex-col items-center justify-center overflow-hidden bg-black"
    >
      {/* Background layers */}
      <motion.div className="absolute inset-0" style={{ y: starsY, scale }}>
        <Stars />
      </motion.div>

      {/* Deep space gradient */}
      <div className="absolute inset-0 bg-gradient-radial from-[#0d0d2b] via-black to-black opacity-80" />

      {/* Grid overlay */}
      <div className="absolute inset-0 grid-bg opacity-20" />

      {/* Animated center glow */}
      <motion.div
        className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] rounded-full"
        style={{
          background: 'radial-gradient(circle, rgba(0,245,255,0.07) 0%, transparent 70%)',
        }}
        animate={{ scale: [1, 1.3, 1], opacity: [0.4, 0.8, 0.4] }}
        transition={{ duration: 5, repeat: Infinity, ease: 'easeInOut' }}
      />

      {/* Orbiting rings */}
      {[240, 360, 480].map((size, i) => (
        <motion.div
          key={size}
          className="absolute top-1/2 left-1/2 rounded-full border border-[#00f5ff]/10"
          style={{
            width: size,
            height: size,
            marginLeft: -size / 2,
            marginTop: -size / 2,
          }}
          animate={{ rotate: i % 2 === 0 ? 360 : -360 }}
          transition={{ duration: 20 + i * 10, repeat: Infinity, ease: 'linear' }}
        />
      ))}

      {/* Main content */}
      <motion.div
        className="relative z-10 text-center px-6 max-w-5xl mx-auto"
        style={{ y: titleY, opacity }}
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        {/* Eyebrow */}
        <motion.div variants={itemVariants} className="mb-6">
          <span className="font-mono text-xs tracking-[0.5em] text-[#00f5ff]/70 uppercase">
            A Digital Time Machine
          </span>
        </motion.div>

        {/* Main title */}
        <motion.div variants={itemVariants} className="relative">
          <h1 className="font-display text-[clamp(5rem,18vw,14rem)] leading-none text-white relative">
            <span
              className="glitch-effect relative inline-block"
              data-text="TIME"
              style={{ color: '#00f5ff', textShadow: '0 0 40px #00f5ff66' }}
            >
              TIME
            </span>
            <span className="text-white/90">SCAPE</span>
          </h1>
        </motion.div>

        {/* Subtitle */}
        <motion.div variants={itemVariants} style={{ y: subtitleY }}>
          <p className="font-body text-lg md:text-xl text-white/50 mt-4 tracking-wide max-w-2xl mx-auto">
            Journey through 60 years of the internet — from ARPANET to AI.
            <br />
            <span className="text-[#00f5ff]/70">Scroll to travel through time.</span>
          </p>
        </motion.div>

        {/* Year badges */}
        <motion.div
          variants={itemVariants}
          className="flex flex-wrap items-center justify-center gap-3 mt-10"
        >
          {['1960s', '1990s', '2000s', '2010s', '2030+'].map((yr, i) => (
            <motion.span
              key={yr}
              className="font-mono text-xs px-4 py-2 rounded-full border border-white/20 text-white/50"
              whileHover={{
                borderColor: '#00f5ff',
                color: '#00f5ff',
                boxShadow: '0 0 20px rgba(0,245,255,0.3)',
                scale: 1.05,
              }}
              transition={{ duration: 0.2 }}
            >
              {yr}
            </motion.span>
          ))}
        </motion.div>

        {/* CTA */}
        <motion.div variants={itemVariants} className="mt-12">
          <motion.button
            onClick={() => document.getElementById('early-internet')?.scrollIntoView({ behavior: 'smooth' })}
            className="relative group font-mono text-sm px-8 py-4 rounded-full border border-[#00f5ff]/50 text-[#00f5ff] overflow-hidden"
            whileHover={{ scale: 1.05, borderColor: '#00f5ff' }}
            whileTap={{ scale: 0.97 }}
          >
            <span className="relative z-10">BEGIN JOURNEY →</span>
            <motion.div
              className="absolute inset-0 bg-[#00f5ff]/10"
              initial={{ x: '-100%' }}
              whileHover={{ x: 0 }}
              transition={{ duration: 0.3 }}
            />
          </motion.button>
        </motion.div>
      </motion.div>

      {/* Scroll indicator */}
      <motion.div
        className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2"
        style={{ opacity }}
        animate={{ y: [0, 8, 0] }}
        transition={{ duration: 2, repeat: Infinity }}
      >
        <span className="font-mono text-[10px] text-white/30 tracking-widest">SCROLL</span>
        <div className="w-[1px] h-10 bg-gradient-to-b from-[#00f5ff]/50 to-transparent" />
      </motion.div>

      {/* Noise overlay */}
      <div className="noise-overlay" />
    </section>
  )
}
