import { useRef, useState } from 'react'
import { motion, useScroll, useTransform, useInView, AnimatePresence } from 'framer-motion'
import { futureFeatures } from '../data/timeline'

function NeonGrid() {
  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none">
      {/* Perspective grid floor */}
      <div
        className="absolute bottom-0 left-0 right-0 h-1/2"
        style={{
          background: `
            linear-gradient(rgba(0,245,255,0.08) 1px, transparent 1px),
            linear-gradient(90deg, rgba(0,245,255,0.08) 1px, transparent 1px)
          `,
          backgroundSize: '60px 60px',
          transform: 'perspective(500px) rotateX(60deg)',
          transformOrigin: 'bottom center',
        }}
      />
      {/* Horizon glow */}
      <div
        className="absolute left-0 right-0"
        style={{
          bottom: '50%',
          height: '2px',
          background: 'linear-gradient(90deg, transparent, #00f5ff, #ff006e, #00f5ff, transparent)',
          boxShadow: '0 0 30px #00f5ff, 0 0 60px #ff006e',
        }}
      />
    </div>
  )
}

function FeatureCard({ feature, index }) {
  const [expanded, setExpanded] = useState(false)
  const ref = useRef(null)
  const inView = useInView(ref, { once: true, margin: '-10%' })

  return (
    <motion.div
      ref={ref}
      className="relative rounded-2xl overflow-hidden cursor-pointer"
      style={{
        border: `1px solid ${feature.color}33`,
        background: `linear-gradient(135deg, ${feature.color}0a, rgba(0,0,0,0.8))`,
      }}
      initial={{ opacity: 0, y: 60, scale: 0.95 }}
      animate={inView ? { opacity: 1, y: 0, scale: 1 } : {}}
      transition={{ delay: index * 0.15, duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
      onClick={() => setExpanded(!expanded)}
      whileHover={{
        borderColor: `${feature.color}88`,
        boxShadow: `0 0 30px ${feature.color}22, 0 0 60px ${feature.color}11`,
      }}
      data-cursor="hover"
    >
      {/* Animated corner accent */}
      <div
        className="absolute top-0 right-0 w-16 h-16 opacity-20"
        style={{
          background: `linear-gradient(225deg, ${feature.color}, transparent)`,
        }}
      />

      <div className="p-6">
        <div className="flex items-start justify-between mb-4">
          <motion.span
            className="text-4xl"
            animate={{ rotate: expanded ? 15 : 0, scale: expanded ? 1.2 : 1 }}
            transition={{ duration: 0.3 }}
          >
            {feature.icon}
          </motion.span>
          <motion.div
            className="font-mono text-xs px-2 py-1 rounded-full"
            style={{ color: feature.color, border: `1px solid ${feature.color}44`, background: `${feature.color}11` }}
            animate={{ rotate: expanded ? 45 : 0 }}
          >
            +
          </motion.div>
        </div>

        <h3
          className="font-future text-xl mb-2"
          style={{ color: feature.color, textShadow: `0 0 20px ${feature.color}66` }}
        >
          {feature.title}
        </h3>

        <AnimatePresence>
          {expanded && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              transition={{ duration: 0.4 }}
            >
              <p className="font-body text-sm text-white/60 leading-relaxed mb-4">{feature.desc}</p>
              <div className="flex flex-wrap gap-2">
                {feature.tags.map(tag => (
                  <span
                    key={tag}
                    className="font-mono text-[10px] px-2 py-1 rounded"
                    style={{ background: `${feature.color}22`, color: feature.color }}
                  >
                    {tag}
                  </span>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {!expanded && (
          <p className="font-body text-xs text-white/30 line-clamp-2">{feature.desc}</p>
        )}
      </div>

      {/* Scan line on hover */}
      <motion.div
        className="absolute inset-x-0 h-[1px] pointer-events-none"
        style={{ background: `linear-gradient(90deg, transparent, ${feature.color}, transparent)` }}
        animate={{ top: ['0%', '100%'] }}
        transition={{ duration: 2, repeat: Infinity, ease: 'linear' }}
        initial={{ opacity: 0 }}
        whileHover={{ opacity: 1 }}
      />
    </motion.div>
  )
}

function FloatingOrbs() {
  return (
    <div className="absolute inset-0 pointer-events-none overflow-hidden">
      {[
        { color: '#00f5ff', size: 300, x: '10%', y: '20%', dur: 8 },
        { color: '#ff006e', size: 200, x: '80%', y: '60%', dur: 12 },
        { color: '#bf5af2', size: 250, x: '60%', y: '15%', dur: 10 },
        { color: '#39ff14', size: 150, x: '30%', y: '75%', dur: 7 },
      ].map((orb, i) => (
        <motion.div
          key={i}
          className="absolute rounded-full"
          style={{
            width: orb.size,
            height: orb.size,
            left: orb.x,
            top: orb.y,
            background: `radial-gradient(circle, ${orb.color}18 0%, transparent 70%)`,
          }}
          animate={{
            x: [0, 30, -20, 0],
            y: [0, -25, 15, 0],
            scale: [1, 1.1, 0.95, 1],
          }}
          transition={{
            duration: orb.dur,
            repeat: Infinity,
            ease: 'easeInOut',
          }}
        />
      ))}
    </div>
  )
}

export default function FutureWeb() {
  const ref = useRef(null)
  const sectionRef = useRef(null)
  const inView = useInView(sectionRef, { once: true, margin: '-20%' })
  const { scrollYProgress } = useScroll({ target: ref, offset: ['start end', 'end start'] })
  const bgY = useTransform(scrollYProgress, [0, 1], ['-5%', '5%'])

  return (
    <section
      id="future-web"
      ref={ref}
      className="relative min-h-screen overflow-hidden"
      style={{ background: '#000008' }}
    >
      <motion.div className="absolute inset-0" style={{ y: bgY }}>
        <FloatingOrbs />
        <NeonGrid />
      </motion.div>

      <div className="noise-overlay" />

      <div ref={sectionRef} className="relative z-10 max-w-6xl mx-auto px-6 py-24 lg:py-32">

        {/* Header */}
        <motion.div
          className="mb-16"
          initial={{ opacity: 0, y: 40 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
        >
          <div className="font-mono text-xs text-[#00f5ff]/60 tracking-[0.5em] mb-3">
            CHAPTER_04 / WHAT_COMES_NEXT
          </div>
          <h2
            className="font-future font-black text-[clamp(2.5rem,9vw,7rem)] leading-none neon-pulse"
            style={{ color: '#00f5ff' }}
          >
            FUTURE<br />
            <span style={{ color: '#ff006e', textShadow: '0 0 40px #ff006e66' }}>WEB</span>
          </h2>
          <div className="font-mono text-white/30 mt-2 text-sm">2030+ — The Next Frontier</div>
        </motion.div>

        {/* Intro */}
        <motion.p
          className="font-body text-lg text-white/50 max-w-2xl mb-16 leading-relaxed"
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 0.3, duration: 0.7 }}
        >
          The internet is entering its third act. <span className="text-white">AI becomes the interface. 
          Blockchain becomes the ledger. Reality becomes the screen.</span> The boundaries between 
          physical and digital dissolve completely.
        </motion.p>

        {/* Feature cards */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-20">
          {futureFeatures.map((feature, i) => (
            <FeatureCard key={feature.id} feature={feature} index={i} />
          ))}
        </div>

        {/* Timeline bar */}
        <motion.div
          className="relative"
          initial={{ opacity: 0, y: 40 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 0.8, duration: 0.8 }}
        >
          <div className="font-mono text-xs text-[#00f5ff]/40 tracking-widest mb-6">
            PROJECTED_TIMELINE ::
          </div>
          <div className="relative">
            {/* Timeline line */}
            <div className="absolute left-0 right-0 top-4 h-[1px] bg-gradient-to-r from-[#00f5ff]/50 via-[#ff006e]/50 to-[#bf5af2]/50" />

            <div className="grid grid-cols-2 md:grid-cols-5 gap-4 relative">
              {[
                { year: '2025', event: 'AGI Research', color: '#00f5ff' },
                { year: '2026', event: 'AR Glasses Mass Market', color: '#39ff14' },
                { year: '2027', event: 'Web3 Mainstream', color: '#bf5af2' },
                { year: '2028', event: 'Neural Interfaces', color: '#ff006e' },
                { year: '2030+', event: 'Spatial Computing', color: '#ffff00' },
              ].map((item, i) => (
                <motion.div
                  key={item.year}
                  className="relative pt-8 text-center"
                  initial={{ opacity: 0, y: 20 }}
                  animate={inView ? { opacity: 1, y: 0 } : {}}
                  transition={{ delay: 1 + i * 0.1 }}
                  whileHover={{ scale: 1.05 }}
                  data-cursor="hover"
                >
                  {/* Dot */}
                  <div
                    className="absolute top-[12px] left-1/2 -translate-x-1/2 w-3 h-3 rounded-full border-2"
                    style={{
                      borderColor: item.color,
                      background: 'black',
                      boxShadow: `0 0 10px ${item.color}`,
                    }}
                  />
                  <div className="font-future text-sm" style={{ color: item.color }}>{item.year}</div>
                  <div className="font-body text-xs text-white/40 mt-1 leading-tight">{item.event}</div>
                </motion.div>
              ))}
            </div>
          </div>
        </motion.div>

        {/* Closing statement */}
        <motion.div
          className="mt-24 text-center"
          initial={{ opacity: 0, scale: 0.95 }}
          animate={inView ? { opacity: 1, scale: 1 } : {}}
          transition={{ delay: 1.2, duration: 0.8 }}
        >
          <div
            className="inline-block font-future text-[clamp(1rem,3vw,2rem)] px-8 py-6 rounded-2xl border"
            style={{
              borderColor: '#00f5ff33',
              background: 'linear-gradient(135deg, rgba(0,245,255,0.05), rgba(255,0,110,0.05))',
              color: '#00f5ff',
              textShadow: '0 0 20px #00f5ff44',
            }}
          >
            "The internet is not done with us yet."
          </div>
          <p className="font-mono text-xs text-white/20 mt-4 tracking-wider">END OF TIMELINE — SCROLL TO RESTART</p>
        </motion.div>
      </div>
    </section>
  )
}
