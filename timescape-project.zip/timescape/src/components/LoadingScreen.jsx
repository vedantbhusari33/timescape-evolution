import { useEffect, useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'

const bootMessages = [
  '> INITIALIZING TIMESCAPE PROTOCOL...',
  '> LOADING ARPANET ARCHIVES...',
  '> SCANNING INTERNET HISTORY...',
  '> CALIBRATING TEMPORAL ENGINE...',
  '> CONNECTING TO DIGITAL TIMELINE...',
  '> BOOT SEQUENCE COMPLETE',
]

export default function LoadingScreen({ onComplete }) {
  const [progress, setProgress] = useState(0)
  const [currentMsg, setCurrentMsg] = useState(0)
  const [done, setDone] = useState(false)

  useEffect(() => {
    const interval = setInterval(() => {
      setProgress(prev => {
        const next = prev + Math.random() * 18 + 5
        if (next >= 100) {
          clearInterval(interval)
          setTimeout(() => {
            setDone(true)
            setTimeout(onComplete, 800)
          }, 400)
          return 100
        }
        return next
      })
    }, 120)

    const msgInterval = setInterval(() => {
      setCurrentMsg(prev => Math.min(prev + 1, bootMessages.length - 1))
    }, 450)

    return () => {
      clearInterval(interval)
      clearInterval(msgInterval)
    }
  }, [onComplete])

  return (
    <AnimatePresence>
      {!done && (
        <motion.div
          className="fixed inset-0 z-[99999] flex flex-col items-center justify-center bg-black overflow-hidden"
          exit={{ opacity: 0, scale: 1.05 }}
          transition={{ duration: 0.8, ease: [0.76, 0, 0.24, 1] }}
        >
          {/* Grid background */}
          <div className="absolute inset-0 grid-bg opacity-30" />

          {/* Center content */}
          <div className="relative z-10 flex flex-col items-center gap-8 px-6 w-full max-w-lg">
            {/* Logo mark */}
            <motion.div
              className="relative"
              initial={{ scale: 0, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ duration: 0.6, ease: [0.175, 0.885, 0.32, 1.275] }}
            >
              {/* Outer ring */}
              <div className="w-28 h-28 rounded-full border border-[#00f5ff]/20 flex items-center justify-center relative">
                {/* Spinning ring */}
                <motion.div
                  className="absolute inset-0 rounded-full border-2 border-transparent border-t-[#00f5ff]"
                  animate={{ rotate: 360 }}
                  transition={{ duration: 1.5, repeat: Infinity, ease: 'linear' }}
                />
                {/* Inner spinning ring */}
                <motion.div
                  className="absolute inset-3 rounded-full border border-transparent border-b-[#ff006e]"
                  animate={{ rotate: -360 }}
                  transition={{ duration: 2.5, repeat: Infinity, ease: 'linear' }}
                />
                {/* Center icon */}
                <motion.span
                  className="text-4xl"
                  animate={{ scale: [1, 1.2, 1] }}
                  transition={{ duration: 2, repeat: Infinity }}
                >
                  ⚡
                </motion.span>
              </div>
            </motion.div>

            {/* Title */}
            <motion.div
              className="text-center"
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.3 }}
            >
              <div className="font-display text-5xl text-white tracking-widest" style={{ letterSpacing: '0.2em' }}>
                TIMESCAPE
              </div>
              <div className="font-mono text-xs text-[#00f5ff]/60 tracking-[0.4em] mt-1">
                EVOLUTION OF THE INTERNET
              </div>
            </motion.div>

            {/* Terminal log */}
            <motion.div
              className="w-full bg-[#050505] border border-[#00ff41]/20 rounded p-4 font-mono text-xs text-[#00ff41] space-y-1"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5 }}
            >
              {bootMessages.slice(0, currentMsg + 1).map((msg, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  className={i === currentMsg ? 'terminal-cursor' : ''}
                >
                  {msg}
                </motion.div>
              ))}
            </motion.div>

            {/* Progress bar */}
            <motion.div
              className="w-full"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.6 }}
            >
              <div className="flex justify-between font-mono text-xs text-[#00f5ff]/50 mb-2">
                <span>LOADING</span>
                <span>{Math.round(progress)}%</span>
              </div>
              <div className="w-full h-1 bg-white/10 rounded-full overflow-hidden">
                <motion.div
                  className="h-full progress-bar rounded-full"
                  style={{ width: `${progress}%` }}
                  transition={{ ease: 'linear' }}
                />
              </div>
            </motion.div>
          </div>

          {/* Corner decorations */}
          <div className="absolute top-4 left-4 font-mono text-[10px] text-[#00f5ff]/30">
            SYS v2.0.26
          </div>
          <div className="absolute top-4 right-4 font-mono text-[10px] text-[#00f5ff]/30">
            TEMPORAL_ENGINE
          </div>
          <div className="absolute bottom-4 left-4 font-mono text-[10px] text-[#00f5ff]/30">
            NODE::ACTIVE
          </div>
          <div className="absolute bottom-4 right-4 font-mono text-[10px] text-[#00f5ff]/30">
            MEM OK
          </div>

          {/* Floating particles */}
          {Array.from({ length: 20 }).map((_, i) => (
            <motion.div
              key={i}
              className="absolute w-1 h-1 rounded-full bg-[#00f5ff]"
              style={{
                left: `${Math.random() * 100}%`,
                bottom: '-10px',
                opacity: 0.4,
              }}
              animate={{
                y: [0, -(window.innerHeight + 20)],
                x: [0, (Math.random() - 0.5) * 100],
                opacity: [0, 0.6, 0.6, 0],
              }}
              transition={{
                duration: 3 + Math.random() * 4,
                repeat: Infinity,
                delay: Math.random() * 3,
                ease: 'linear',
              }}
            />
          ))}
        </motion.div>
      )}
    </AnimatePresence>
  )
}
