import { motion } from 'framer-motion'

export default function SectionTransition({ fromColor = '#000', toColor = '#000', id }) {
  return (
    <div
      id={id}
      className="relative h-24 overflow-hidden"
      style={{ background: fromColor }}
    >
      <div
        className="absolute inset-0"
        style={{
          background: `linear-gradient(to bottom, ${fromColor}, ${toColor})`,
        }}
      />
      {/* Decorative scan line */}
      <motion.div
        className="absolute inset-x-0 h-[2px]"
        style={{
          background: 'linear-gradient(90deg, transparent, rgba(0,245,255,0.5), transparent)',
          top: '50%',
        }}
        animate={{ scaleX: [0, 1, 0], opacity: [0, 1, 0] }}
        transition={{ duration: 2, repeat: Infinity, repeatDelay: 1 }}
      />
    </div>
  )
}
