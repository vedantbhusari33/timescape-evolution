import { useRef, useState } from 'react'
import { motion, useScroll, useTransform, useInView, AnimatePresence } from 'framer-motion'
import { socialMediaApps } from '../data/timeline'

function AppCard({ app, index }) {
  const [flipped, setFlipped] = useState(false)

  return (
    <motion.div
      className="relative h-48 cursor-pointer"
      style={{ perspective: 1000 }}
      initial={{ opacity: 0, y: 60, rotate: index % 2 === 0 ? -5 : 5 }}
      whileInView={{ opacity: 1, y: 0, rotate: 0 }}
      viewport={{ once: true, margin: '-10%' }}
      transition={{ delay: index * 0.1, duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
      onClick={() => setFlipped(!flipped)}
      data-cursor="hover"
    >
      <motion.div
        className="relative w-full h-full"
        style={{ transformStyle: 'preserve-3d' }}
        animate={{ rotateY: flipped ? 180 : 0 }}
        transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
      >
        {/* Front */}
        <div
          className="absolute inset-0 rounded-2xl p-5 flex flex-col justify-between overflow-hidden social-card"
          style={{
            backfaceVisibility: 'hidden',
            background: `linear-gradient(135deg, ${app.color}22, ${app.color}11)`,
            border: `1px solid ${app.color}44`,
          }}
        >
          <div className="flex items-start justify-between">
            <span className="text-4xl">{app.icon}</span>
            <span
              className="font-mono text-xs px-2 py-1 rounded-full"
              style={{ background: `${app.color}22`, color: app.color }}
            >
              {app.year}
            </span>
          </div>
          <div>
            <h3 className="font-display text-2xl text-white tracking-wide">{app.name}</h3>
            <div
              className="font-mono text-[10px] mt-1 opacity-60"
              style={{ color: app.color }}
            >
              TAP TO LEARN MORE
            </div>
          </div>
          {/* Glow */}
          <div
            className="absolute inset-0 opacity-0 hover:opacity-100 transition-opacity duration-300 rounded-2xl"
            style={{ background: `radial-gradient(circle at 50% 50%, ${app.color}15, transparent 70%)` }}
          />
        </div>

        {/* Back */}
        <div
          className="absolute inset-0 rounded-2xl p-5 flex flex-col justify-center items-center text-center"
          style={{
            backfaceVisibility: 'hidden',
            transform: 'rotateY(180deg)',
            background: `linear-gradient(135deg, ${app.color}33, ${app.color}11)`,
            border: `1px solid ${app.color}66`,
          }}
        >
          <span className="text-3xl mb-3">{app.icon}</span>
          <h3 className="font-display text-xl text-white mb-2">{app.name}</h3>
          <p className="font-body text-sm text-white/70 leading-relaxed">{app.desc}</p>
          <div className="mt-3 font-mono text-[10px]" style={{ color: app.color }}>
            FOUNDED {app.year}
          </div>
        </div>
      </motion.div>
    </motion.div>
  )
}

export default function SocialMedia() {
  const ref = useRef(null)
  const sectionRef = useRef(null)
  const inView = useInView(sectionRef, { once: true, margin: '-20%' })
  const { scrollYProgress } = useScroll({ target: ref, offset: ['start end', 'end start'] })
  const bgY = useTransform(scrollYProgress, [0, 1], ['-5%', '5%'])

  return (
    <section
      id="social-media"
      ref={ref}
      className="relative min-h-screen overflow-hidden"
      style={{ background: '#0a0010' }}
    >
      {/* Colorful gradient background */}
      <motion.div className="absolute inset-0" style={{ y: bgY }}>
        <div className="absolute inset-0"
          style={{
            background: 'radial-gradient(ellipse at 20% 30%, #ff006e22 0%, transparent 50%), radial-gradient(ellipse at 80% 70%, #1877f222 0%, transparent 50%), radial-gradient(ellipse at 50% 50%, #bf5af222 0%, transparent 60%)',
          }}
        />
        {/* Confetti dots */}
        {Array.from({ length: 30 }).map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-2 h-2 rounded-full"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              background: ['#ff006e', '#1877f2', '#25d366', '#ffff00', '#bf5af2'][i % 5],
              opacity: 0.15,
            }}
            animate={{
              y: [0, -30, 0],
              opacity: [0.1, 0.3, 0.1],
            }}
            transition={{
              duration: 3 + Math.random() * 3,
              repeat: Infinity,
              delay: Math.random() * 3,
            }}
          />
        ))}
      </motion.div>

      <div className="noise-overlay" />

      <div ref={sectionRef} className="relative z-10 max-w-6xl mx-auto px-6 py-24 lg:py-32">

        {/* Header */}
        <motion.div
          className="mb-16"
          initial={{ opacity: 0, y: 40 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
        >
          <div className="font-mono text-xs text-[#ff006e]/60 tracking-[0.5em] mb-3">
            CHAPTER_02 / THE_SOCIAL_EXPLOSION
          </div>
          <h2
            className="font-display text-[clamp(3rem,10vw,8rem)] leading-none"
            style={{
              background: 'linear-gradient(135deg, #ff006e, #bf5af2, #1877f2)',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
              backgroundClip: 'text',
            }}
          >
            SOCIAL<br />MEDIA BOOM
          </h2>
          <div className="font-mono text-white/30 mt-2 text-sm">2000s — The Decade of Connection</div>
        </motion.div>

        {/* Intro text */}
        <motion.p
          className="font-body text-lg text-white/60 max-w-xl mb-12 leading-relaxed"
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 0.3, duration: 0.7 }}
        >
          The internet stopped being a tool and became a <span className="text-white">social fabric</span>. 
          Billions of people found their voice, their tribe — and their addiction.
        </motion.p>

        {/* App cards grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-16">
          {socialMediaApps.map((app, i) => (
            <AppCard key={app.name} app={app} index={i} />
          ))}
        </div>

        {/* Stats bar */}
        <motion.div
          className="grid grid-cols-2 md:grid-cols-4 gap-4"
          initial={{ opacity: 0, y: 40 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 0.6, duration: 0.8 }}
        >
          {[
            { value: '5B+', label: 'Social Media Users', color: '#1877f2' },
            { value: '500M', label: 'Tweets Per Day', color: '#1da1f2' },
            { value: '95M', label: 'Instagram Posts/Day', color: '#e1306c' },
            { value: '500hrs', label: 'YouTube/Minute', color: '#ff0000' },
          ].map((stat, i) => (
            <motion.div
              key={stat.label}
              className="rounded-2xl p-5 border border-white/10 bg-white/5 backdrop-blur-sm text-center"
              whileHover={{
                scale: 1.05,
                borderColor: stat.color,
                boxShadow: `0 0 30px ${stat.color}33`,
              }}
              transition={{ duration: 0.2 }}
              data-cursor="hover"
            >
              <div
                className="font-display text-3xl"
                style={{ color: stat.color }}
              >
                {stat.value}
              </div>
              <div className="font-body text-xs text-white/50 mt-1">{stat.label}</div>
            </motion.div>
          ))}
        </motion.div>

        {/* Quote */}
        <motion.div
          className="mt-16 text-center"
          initial={{ opacity: 0 }}
          animate={inView ? { opacity: 1 } : {}}
          transition={{ delay: 1, duration: 0.8 }}
        >
          <p className="font-body text-xl text-white/40 italic max-w-2xl mx-auto leading-relaxed">
            "We didn't know we were building a <span className="text-white/80 not-italic">surveillance engine</span> — 
            we thought we were building a <span className="text-white/80 not-italic">social network</span>."
          </p>
        </motion.div>
      </div>
    </section>
  )
}
