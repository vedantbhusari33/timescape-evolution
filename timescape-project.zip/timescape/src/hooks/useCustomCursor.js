import { useEffect, useRef } from 'react'

export function useCustomCursor() {
  const dotRef = useRef(null)
  const ringRef = useRef(null)
  const mousePos = useRef({ x: 0, y: 0 })
  const ringPos = useRef({ x: 0, y: 0 })
  const rafId = useRef(null)

  useEffect(() => {
    const dot = dotRef.current
    const ring = ringRef.current
    if (!dot || !ring) return

    const lerp = (start, end, factor) => start + (end - start) * factor

    const animate = () => {
      ringPos.current.x = lerp(ringPos.current.x, mousePos.current.x, 0.15)
      ringPos.current.y = lerp(ringPos.current.y, mousePos.current.y, 0.15)

      dot.style.transform = `translate(${mousePos.current.x - 4}px, ${mousePos.current.y - 4}px)`
      ring.style.transform = `translate(${ringPos.current.x - 16}px, ${ringPos.current.y - 16}px)`

      rafId.current = requestAnimationFrame(animate)
    }

    const onMouseMove = (e) => {
      mousePos.current = { x: e.clientX, y: e.clientY }
    }

    const onMouseEnterInteractive = () => {
      ring.classList.add('hovering')
    }

    const onMouseLeaveInteractive = () => {
      ring.classList.remove('hovering')
    }

    const addListeners = () => {
      const interactiveEls = document.querySelectorAll('button, a, [data-cursor="hover"], .social-card, .timeline-nav-btn')
      interactiveEls.forEach(el => {
        el.addEventListener('mouseenter', onMouseEnterInteractive)
        el.addEventListener('mouseleave', onMouseLeaveInteractive)
      })
    }

    window.addEventListener('mousemove', onMouseMove)
    rafId.current = requestAnimationFrame(animate)

    // Re-add listeners when DOM updates
    const observer = new MutationObserver(addListeners)
    observer.observe(document.body, { childList: true, subtree: true })
    addListeners()

    return () => {
      window.removeEventListener('mousemove', onMouseMove)
      cancelAnimationFrame(rafId.current)
      observer.disconnect()
    }
  }, [])

  return { dotRef, ringRef }
}
