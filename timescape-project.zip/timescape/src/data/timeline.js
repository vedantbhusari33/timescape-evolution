export const timelineData = [
  {
    id: 'hero',
    label: 'Intro',
    year: '∞',
    color: '#00f5ff',
  },
  {
    id: 'early-internet',
    label: 'Early Web',
    year: '1960s–90s',
    color: '#00ff41',
  },
  {
    id: 'social-media',
    label: 'Social Era',
    year: '2000s',
    color: '#ff006e',
  },
  {
    id: 'mobile-era',
    label: 'Mobile',
    year: '2010s',
    color: '#bf5af2',
  },
  {
    id: 'future-web',
    label: 'Future',
    year: '2030+',
    color: '#ffff00',
  },
]

export const earlyInternetEvents = [
  { year: '1969', event: 'ARPANET goes live', desc: 'First message sent between UCLA and Stanford' },
  { year: '1971', event: 'Email invented', desc: 'Ray Tomlinson sends the first network email' },
  { year: '1983', event: 'TCP/IP adopted', desc: 'The modern internet protocol suite is born' },
  { year: '1989', event: 'WWW invented', desc: "Tim Berners-Lee proposes the World Wide Web" },
  { year: '1993', event: 'Mosaic browser', desc: 'First graphical web browser launches' },
  { year: '1995', event: 'Amazon & eBay', desc: 'E-commerce starts transforming retail' },
  { year: '1998', event: 'Google founded', desc: 'A search engine changes everything' },
]

export const socialMediaApps = [
  { name: 'MySpace', year: '2003', color: '#1f6fff', icon: '🎵', desc: 'First social network for the masses' },
  { name: 'Facebook', year: '2004', color: '#1877f2', icon: '👥', desc: 'Connect with friends and family' },
  { name: 'YouTube', year: '2005', color: '#ff0000', icon: '▶️', desc: 'Broadcast yourself to the world' },
  { name: 'Twitter', year: '2006', color: '#1da1f2', icon: '🐦', desc: 'What are you doing right now?' },
  { name: 'iPhone', year: '2007', color: '#555', icon: '📱', desc: 'The internet in your pocket' },
  { name: 'Instagram', year: '2010', color: '#e1306c', icon: '📸', desc: 'Share your world through photos' },
]

export const mobileStats = [
  { label: 'Mobile Users', value: '6.9B', unit: 'worldwide', icon: '📱' },
  { label: 'Apps in Store', value: '4.8M', unit: 'combined', icon: '🛍️' },
  { label: 'Daily Usage', value: '4.8h', unit: 'avg/person', icon: '⏱️' },
  { label: 'Data/Month', value: '21GB', unit: 'avg user', icon: '📊' },
]

export const futureFeatures = [
  {
    id: 'web3',
    title: 'Web3 & Blockchain',
    desc: 'Decentralized ownership, NFTs, and smart contracts reshape the digital economy. No more middlemen.',
    icon: '⛓️',
    color: '#bf5af2',
    tags: ['DeFi', 'NFTs', 'DAO', 'Crypto'],
  },
  {
    id: 'ai',
    title: 'AI-Native Web',
    desc: 'Intelligent interfaces that learn, adapt, and create. Every website becomes a conversation.',
    icon: '🤖',
    color: '#00f5ff',
    tags: ['LLMs', 'Agents', 'Vision', 'Voice'],
  },
  {
    id: 'xr',
    title: 'XR & Metaverse',
    desc: 'Blending physical and digital realities. Spatial computing replaces flat screens.',
    icon: '🥽',
    color: '#ff006e',
    tags: ['AR', 'VR', 'MR', 'Spatial'],
  },
  {
    id: 'quantum',
    title: 'Quantum Internet',
    desc: 'Unhackable communication via quantum entanglement. Speed of light security.',
    icon: '⚛️',
    color: '#39ff14',
    tags: ['Qubits', 'Encryption', 'Teleport', 'Speed'],
  },
]
